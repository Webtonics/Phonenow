<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your eSIM is Ready</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 40px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #3B82F6;
            font-size: 28px;
            margin: 0;
        }
        h2 {
            color: #1f2937;
            margin-bottom: 20px;
        }
        p {
            color: #4b5563;
            margin-bottom: 15px;
        }
        .success-badge {
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background-color: #ecfdf5;
            border-radius: 8px;
            border: 1px solid #a7f3d0;
        }
        .success-badge span {
            color: #065f46;
            font-weight: 600;
            font-size: 18px;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .details-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f3f4f6;
        }
        .details-table td:first-child {
            color: #6b7280;
            font-size: 14px;
            width: 40%;
        }
        .details-table td:last-child {
            color: #1f2937;
            font-weight: 600;
        }
        .activation-code {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 15px;
            margin: 20px 0;
            word-break: break-all;
            font-family: monospace;
            font-size: 13px;
            color: #374151;
        }
        .button {
            display: inline-block;
            background-color: #3B82F6;
            color: #ffffff !important;
            text-decoration: none;
            padding: 14px 30px;
            border-radius: 6px;
            font-weight: 600;
            margin: 20px 0;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            font-size: 12px;
            color: #9ca3af;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>PhoneNow</h1>
        </div>

        <div class="success-badge">
            <span>Your eSIM is Ready!</span>
        </div>

        <p>Hello <?php echo e($profile->user->name); ?>,</p>

        <p>Great news! Your eSIM order for <strong><?php echo e($profile->country_name); ?></strong> has been fulfilled and is ready to install on your device.</p>

        <table class="details-table">
            <tr>
                <td>Order Number</td>
                <td><?php echo e($profile->order_no); ?></td>
            </tr>
            <tr>
                <td>Country</td>
                <td><?php echo e($profile->country_name); ?></td>
            </tr>
            <tr>
                <td>Data</td>
                <td><?php echo e($profile->formatted_data); ?></td>
            </tr>
            <tr>
                <td>Validity</td>
                <td><?php echo e($profile->duration_days); ?> days</td>
            </tr>
            <?php if($profile->iccid): ?>
            <tr>
                <td>ICCID</td>
                <td><?php echo e($profile->iccid); ?></td>
            </tr>
            <?php endif; ?>
        </table>

        <?php if($lpaString): ?>
        <p><strong>Activation Code (LPA):</strong></p>
        <div class="activation-code"><?php echo e($lpaString); ?></div>
        <?php endif; ?>

        <p>To install your eSIM, go to your phone's Settings and add an eSIM using the QR code or activation code available in your account.</p>

        <p style="text-align: center;">
            <a href="<?php echo e($viewUrl); ?>" class="button">View My eSIMs</a>
        </p>

        <div class="footer">
            <p>&copy; <?php echo e(date('Y')); ?> PhoneNow. All rights reserved.</p>
            <p>This is an automated message, please do not reply.</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\phpworks\phonenow\backend\resources\views/emails/esim-fulfilled.blade.php ENDPATH**/ ?>